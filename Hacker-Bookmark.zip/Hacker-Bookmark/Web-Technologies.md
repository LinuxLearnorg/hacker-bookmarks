
##########BI Web application

-[BI modern web application](https://github.com/apache/incubator-superset)


##### Web Technologies

-[Emerging web techonologies for 2016](https://risingstars2016.js.org/)


###### Build a static web site

-[neocities static web site](https://neocities.org/)
