
########## Bigdata pipeline

-[Big data pipeline diagram](http://xyz.insightdataengineering.com/blog/pipeline_map/)


#####Bunch of example for Streaming data

-[Krill weather, Kafka,Spark,Scala,Cassandra](https://github.com/killrweather/killrweather)

-[Git book](https://www.gitbook.com/)
