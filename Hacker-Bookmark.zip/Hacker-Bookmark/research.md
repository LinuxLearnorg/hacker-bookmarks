## Just thougts on technology.


Javascript:

After a quiet bit of research I have settled down on 3 popular frontend MVC framework,

- backbone.js, it is barebone framework needs lot of plumming 
- Angular.js, the best in the pack
- Knockout.js

- [getting started with angularjs](http://www.adobe.com/devnet/html5/articles/getting-started-with-angularjs.html)
- [fun with angular](http://devgirl.org/2013/03/21/fun-with-angularjs/)
- [Angularjs with D3](https://github.com/fullscale/dangle)
- [angularjs dependency injection](http://www.alexrothenberg.com/2013/02/11/the-magic-behind-angularjs-dependency-injection.html)
- [intro angular js](http://blog.akquinet.de/2013/01/22/maintainable-rich-web-applications-with-angularjs/#more-2552)
- [intro angularjs](http://blog.kaggle.com/2013/01/14/webapps-for-data-scientists-building-your-first-crud/)
- [youtube built on angularjs](https://github.com/mikecrittenden/toogles)
Angular + PhoneGap, exposing backend via REST.

 Angularjs focus on isolate scopes and transclusion which are confusing on john video

realtime,
meteor,derby

phonegap

Visual editor: Inkscape
http://inkscape.org/index.php?lang=en


Hadoop:
- Hadoop streaming
- Hadoop Core MR
- Hbase db
- Hive postcomputing
- Pig  precomputing

Hadoop:
Input data frquencies
volume of incoming data gb
How many node installed clusters
what is data done after computing.

Hadoop:
[wordcount example](http://kickstarthadoop.blogspot.com/2011/04/word-count-hadoop-map-reduce-example.html)

Backend: Java + REST + Amazon EC2 + Hadoop + NoSQL


#### Spring Roo
-  [user management](http://raginggoblin.wordpress.com/)

#### Go
- [Go slide](http://www.slideshare.net/derekcollison/go-conference-japan)

#### Scalability
- [Pinterest](http://highscalability.com/blog/2013/4/15/scaling-pinterest-from-0-to-10s-of-billions-of-page-views-a.html?utm_source=feedly)
