
#### Bunch of hacks,


-[Tracking friends and strangers using WhatsApp](https://robertheaton.com/2017/10/09/tracking-friends-and-strangers-using-whatsapp/)


-[How to find anybodys email](http://nathanleclaire.com/blog/2013/11/23/how-i-automated-finding-almost-anyones-email-address/)

-[Internet of things search engine](https://www.shodan.io/)

-[reverse engineering](http://beginners.re/)
