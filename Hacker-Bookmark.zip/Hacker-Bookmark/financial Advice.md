
#### Financial advice,
- [financial advice](https://news.ycombinator.com/item?id=6396352)
- [Money and Investing advice](https://www.mattcutts.com/blog/make-money-investing-tips/)
