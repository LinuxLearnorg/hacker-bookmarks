
##### Health,

-[Heartattack related](https://news.ycombinator.com/item?id=6671454)
