#### Hacker montly jobs
-[December jobs](https://news.ycombinator.com/item?id=10655740)


#### Good article related to jobs,
- [Must read for software engineers](http://www.kalzumeus.com/greatest-hits/)
- [Algorithm big-O notaion explained](http://justin.abrah.ms/computer-science/big-o-notation-explained.html)
- [Resume:](http://throw-out-your-resume.com/#top)




#### free learning programming,
- [learn to code codecademy](http://www.codecademy.com/learn)
-  [learn to code hardway](http://learncodethehardway.org/)

#### Algorithms,
- [visualize algorithms](https://news.ycombinator.com/item?id=8194662)
- [Algorithms resource](https://news.ycombinator.com/item?id=8200160)
