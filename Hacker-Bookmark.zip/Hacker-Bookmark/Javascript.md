
##### Javascript

-[State of Javascript in 2016](https://medium.com/javascript-and-opinions/state-of-the-art-javascript-in-2016-ab67fc68eb0b#.6eq6h08eo)


#### opne source Dashboards

-[cyclotron](http://www.cyclotron.io/)

-[Grafana](http://grafana.org/)

-[Kibana](https://www.elastic.co/products/kibana)

-[Jenkins](https://jenkins.io/)

