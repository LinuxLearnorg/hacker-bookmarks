#########About spark##########

-[Spark concepts](https://github.com/kubernetes/kubernetes/issues/34377)

-[Spark cluster managers](http://www.agildata.com/apache-spark-cluster-managers-yarn-mesos-or-standalone/)


#########Spark performance ###########

-[Spark gotchas](https://github.com/awesome-spark/spark-gotchas)

-[Spark performance](https://umbertogriffo.gitbooks.io/apache-spark-best-practices-and-tuning/content/sparksqlshufflepartitions_draft.html)

-[Spark shuffle](https://www.slideshare.net/databricks/strata-sj-everyday-im-shuffling-tips-for-writing-better-spark-programs)
