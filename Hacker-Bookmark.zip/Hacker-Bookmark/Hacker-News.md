##### Javascript:
  [Useful meteor links](http://themeteorbook.com/)


##### Startup:
   - [Integrating web services,](https://zapier.com/zapbook/)
   - [Startup Trap:](http://blog.8thlight.com/uncle-bob/2013/03/05/TheStartUpTrap.html)
   - [Your Startup’s Most Important Metrics](http://tomtunguz.com/your-startups-10-most-important-metrics/)
  - [pitch your startup](http://getapitchdeck.com/)
  - [startup design idea, done with meteor](http://pegleg.it/about)
  - [web Tracing framework](http://google.github.io/tracing-framework/)

##### Building iOS Apps,
 - [building a sample airBNB app in 16hrs,](https://blog.stackmob.com/2013/03/build-an-airbnb-clone-in-a-day/)

##### About CEO:
  - [Things about I knew 2 years ago as founder,](https://speakerdeck.com/giladvdn/ten-things-about-being-a-founder-i-wish-i-knew-two-years-ago?x=1)

##### Hacking:
  - [Meet the men who spy on women through their webcams]
  (http://arstechnica.com/tech-policy/2013/03/rat-breeders-meet-the-men-who-spy-on-women-through-their-webcams/)

##### CheatSheet:
 - [Complete explaination of various language cheat sheet](http://overapi.com/)


##### Hadoop Related:
  - [Brains behind facebook hadoop,]
  (http://www.wired.com/wiredenterprise/2013/02/facebook-data-team/)

  - [Hadoop UI]
  (http://www.pentaho.com/)

##### About Clean Architecture:
  - [clean](http://blog.8thlight.com/uncle-bob/2012/08/13/the-clean-architecture.html)

##### Java/J2EE:
 - [j2ee best practices]
 (http://gordondickens.com/wordpress/2012/07/03/enterprise-spring-best-practices-part-1-project-config/)


###### Domain check
- [Instant domain check](http://instantname.me/)
###### Health Ins
  - [simply Insured](http://blog.simplyinsured.com/) 

JOBs:
- [job](http://recruiting.jobvite.com/customers/)
- [How to hire a programmer]((http://blog.kiratalent.com/post/47112553827/12-must-reads-when-recruiting-programmers)

[best techincal talk](https://news.ycombinator.com/item?id=5511466)

####h4 Cloud hosting
 - [Digital ocean](https://www.digitalocean.com/)
 - [Comparison of hosting](https://news.ycombinator.com/item?id=6018486)
 - [Cloud hosting compared with amazon](https://news.ycombinator.com/item?id=6430753)  

#### WYSIWYG Bootstrap,
-  Jetstrap, Divshot, and Easel WYSIWYG Bootstrap apps.

#### VC Funding,
-  [vc funding lessons](http://viniciusvacanti.com/2013/04/16/lessons-learned-raising-6-million/)

#### Rest API Design,
- [Rest Api design](https://www.stormpath.com/blog/secure-your-rest-api-right-way)
- [spring REST authentication](http://www.javacodegeeks.com/2012/05/how-to-use-resttemplate-with-basic.html)
- [Best practices ](http://www.vinaysahni.com/best-practices-for-a-pragmatic-restful-api?hn)
- [RestFul api design](http://info.apigee.com/Portals/62317/docs/web%20api.pdf)
- [what RESTful actually means](https://codewords.recurse.com/issues/five/what-restful-actually-means)


#### Front End design,
- [Front end design](https://github.com/dypsilon/frontend-dev-bookmarks)
- [Divshot, the great bootstrap design tool](http://www.divshot.com/)
- [Bootstrap switch](http://www.bootstrap-switch.org/)

##### Startup Companies:
- [startup website using youtube api](http://en-us.blynde.com/)
- [build using rails simple web](http://www.vutran.me/blog/from-learning-rails-to-deploying-a-saas-app-in-7-days/)

#### Media,
- [MediaCrush is an image hosting website designed for speedy images](https://mediacru.sh/)


### Writing skill,
- [Writing Skill](https://news.ycombinator.com/item?id=6206625)


#### developer,
-[Good site for developer:](https://zapier.com/developer/)

