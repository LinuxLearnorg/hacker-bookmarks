youtube
http://www.youtube.com/watch?v=qyDb7bag9YI&list=RD02NoXf5ZKCvVE

Web site design ideas,
copy newsCreed http://newscred.com/


devloper apps for mac:
http://thetechblock.com/must-have-osx-apps-designers-developers/


below is the list of configuration management tools
- cfEngine
- puppet
- chef
- saltstack
- [ansible is the best](http://devo.ps/blog/2013/07/03/ansible-simply-kicks-ass.html)

- [police video](http://www.youtube.com/watch?v=6wXkI4t7nuc)


#### Priceonmics
- [price guide to everything](http://priceonomics.com/)


#### Digital Inspirations
-[How to Guies](http://www.labnol.org/)


#### Photography
- [This is future of photoraphy](http://www.nytimes.com/newsgraphics/2013/07/21/silk-road/)

find . -name 'pom.xml' |xargs perl -pi -e 's/2.1.17-SNAPSHOT/2.1.16-SNAPSHOT/g'

find ~/.m2  -name "*.lastUpdated" -exec grep -q "Could not transfer" {} \; -print -exec rm {} \;


#### RPM
- [Building RPMs on windows](http://crlog.info/2012/09/11/building-rpms-on-windows/)

- [best practices for sprin j2ee](http://gordondickens.com/wordpress/2012/07/03/enterprise-spring-best-practices-part-1-project-config/)


#### General Ameican police

- [American police](http://chronicle.com/article/The-American-Police-State/142965/)
