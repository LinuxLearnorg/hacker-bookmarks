#### Learn to code
-[Learn to think not to code](http://brikis98.blogspot.com/2014/05/dont-learn-to-code-learn-to-think.html)

#### Language

-[beyond objective-c, beyond swift](http://blog.jaredsinclair.com/post/98402624705/beyond-objective-c-beyond-swift)
