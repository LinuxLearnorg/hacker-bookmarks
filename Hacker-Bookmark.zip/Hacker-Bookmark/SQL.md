
##### DB 

-[Internal of postgres](http://www.interdb.jp/pg/index.html)


##### sql tutorial

-[Sql tutorial](https://selectstarsql.com/)



#### sql

These data warehouses undoubtedly use the standard performance tricks: columnar storage, cost-based query planning, pipelined execution, and just-in-time compilation.
