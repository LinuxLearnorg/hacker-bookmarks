##### static web site
-[free static web site](https://www.netlify.com/pricing/)

-[follow up ](https://news.ycombinator.com/item?id=15755768)

#### Maping solutions
-[geo location](https://opencagedata.com/pricing)
-[cheaper alternative to goolemaps, stadia](https://stadiamaps.com/)

#### photos
-[How To Go Viral By Using Fake Reddit Likes](http://www.hack-pr.com/library/how-we-hacked-reddit-to-generate-5-million-media-impressions-in-3-days)

-[Free photos](https://unsplash.com/collections)


#######startup ########

-[Sam Altman how to startup playbook](https://playbook.samaltman.com/)

-[super founders](https://medium.com/@alitamaseb/land-of-the-super-founders-a-data-driven-approach-to-uncover-the-secrets-of-billion-dollar-a69ebe3f0f45)

-[startuo hacks for real founder](https://news.ycombinator.com/item?id=18400020)

-[Pros and cons of Startup working](https://news.ycombinator.com/item?id=17286939)

-[How to become CEO](https://www.nytimes.com/2017/10/27/business/how-to-be-a-ceo.html)

-[pitching for round A funding](https://blog.atrium.co/the-founders-guide-to-raising-a-series-a-venture-financing-1de4f5aff312)


-[Some tips on creating startup](https://www.process.st/mvp-app/)

-[Marketing checklist](https://www.sideprojectchecklist.com/marketing-checklist/)
-[building a startup](https://levels.io/hoodmaps/)

-[free startup template](https://startbootstrap.com/)

#### Starting a Startup

-[Y combinator startup school](https://www.startupschool.org/register)

-[learn from indiehackers](http://www.toomas.net/2017/07/18/reverse-engineering-a-successful-lifestyle-business-heres-everything-ive-learned-from-reading-indiehackers-com/)


-[Y combinator statup school](https://www.startupschool.org/)


-[Startup truth](https://medium.com/@kenanhopkins/in-2016-i-sold-my-startup-for-seven-figures-a3c60db80947#.icl2lzygm)


-[Successfull one person online business](https://news.ycombinator.com/item?id=13326535)

-[Bootstrapping a Saas Startup](https://medium.com/@cliffordoravec/the-epic-guide-to-bootstrapping-a-saas-startup-from-scratch-by-yourself-part-1-4d834e1df8c1#.l6pjdb17t)


-[Y combinator Tech stack up](http://themacro.com/articles/2016/08/yc-tech-stacks/)

-[Building something like Instagram](http://mlsdev.com/en/blog/70-how-to-develop-an-app-like-instagram)

-[Startup Legal setup guide](https://medium.com/@howietl/the-startup-legal-setup-guide-439b63bf68e8#.p2v0yf8uo)

-[startup legal](https://www.orrick.com/Practices/Emerging-Companies/Pages/Startup-Tool-Kit.aspx)

##### start-up Stories

-[Indiehackers](https://www.indiehackers.com/businesses)
-[A startup story](https://www.indiehackers.com/businesses/instapainting)

#### Startup Ideas

-[Startup finder markmatters](https://mattermark.com/)


#### Stock options

-[Startup stock options explained](https://gist.github.com/yossorion/4965df74fd6da6cdc280ec57e83a202d)
-[follow up comments](https://news.ycombinator.com/item?id=13426494)


#### 2016 Startups Y combinartor
-[How to start a startups Videos](http://startupclass.samaltman.com/)

#### 2015 Things to do
- [Startup failure lessons](http://autopsy.io/)
- [16 things in startup](http://a16z.com/2015/01/22/16-things/)
- [startup sales-agreement](http://blog.ycombinator.com/yc-open-source-sales-agreement)
- [online marketing ](https://growthhackers.com/)
- [57 Startup advice](http://www.defmacro.org/2013/07/23/startup-lessons.html)

#### Startup gotchas
-[When to join startup](http://tomblomfield.com/post/136759441870/when-to-join-a-startup)

#### website generator
-[static web site geneartor](http://cactusformac.com/)

-[Static web site generator](http://launchaco.com/build/)

-[Hosting web site expenses, good one](http://cushionapp.com/expenses/)
-[follow-up comments Hackernews](https://news.ycombinator.com/item?id=10875879)


#### Fund raising
-[Seed fund raising](http://themacro.com/articles/2016/01/how-to-raise-a-seed-round/)

#### product management
- [Product mangement](http://yilunzh.com/pm/)

#### Side projects
-[Making money on side projects](https://news.ycombinator.com/item?id=8844083)
-[ a linkedin hack that led to 120K](http://thehustle.co/the-linkedin-hack-that-made-me-120000)
-[follow up comments](https://news.ycombinator.com/item?id=9957083)

##### build website
-[Build stellar startup website](http://letstalkover.coffee/)

-[web site builder](https://yootheme.com/pro/)

#### Y-combinator

-[Y silicon valley works](https://news.ycombinator.com/item?id=8552487)
-[how it to be y-combinator](http://blog.frontapp.com/three-months-at-y-combinator-what-its-like-and-how-to-get-in/)



#### startup lessons,
-[Startup lessons](http://tech.genius.com/Sam-altman-how-to-start-a-startup-lecture-1-annotated)
-[startup lecture lesson 2](http://startupclass.samaltman.com/courses/lec02/)
-[Startup depression](http://startupdepression.com/)
-[Building startup](https://bloo.ie/blog/building-a-company-brick-by-brick/)

#### Statup Failures,

-[A startup failure lesson](https://news.ycombinator.com/item?id=7933155)

#### Hire contract developers
- [hire contract developers](http://www.trevormckendrick.com/contracting-developers/)
- [comments..](https://news.ycombinator.com/item?id=5713159)
- [hire contract developers](https://news.ycombinator.com/item?id=7064469)

#### on startup website
- [onstartup website ](http://onstartups.com/)
- [venture hacks](http://venturehacks.com/)
- [startup advice](https://iamwil.posterous.com/i-got-into-yc-after-applying-six-times-heres/)


#### How to,
- [how to work offtime at home](http://impossiblehq.com/workstation-popcorn)

#### Startup stock options gotcha
- [startup stock options](http://blog.conspire.com/post/112700131803/if-you-have-startup-stock-options-check-your)
- [startup stock options are useless](http://benjyboxer.com/post/55714250364/the-real-value-of-stock-options)
- [hacker news comment on the above](https://news.ycombinator.com/item?id=6060143)
- [follow up comments](https://news.ycombinator.com/item?id=9145126)

#### A good read on startup friendly
- [42 rules read for startup](http://firstround.com/article/42-Rules-to-Lead-by-from-the-Man-Who-Defined-Googles-Product-Strategy#)
- [How to be 20 Times as Successful with your IT Department](http://marcusblankenship.com/post/55659546590/how-to-be-20-times-as-successful-with-your-it)


#### How to make money by billing differently
- [making money on billing](http://sixrevisions.com/business/earn-more-on-projects/)



#### startup company,
- [web scraping](https://github.com/propublica/upton)
- [YQL another famous scarping tool](http://developer.yahoo.com/yql/guide/yql-code-examples.html)
-[startup tips](http://www.paperv.com/story/939/startup-quotes/)

#### startup raise money
-[How to raise money first time](http://wadefoster.net/post/58039721398/how-to-raise-money-as-a-first-time-founder)
-[Startup lessons](http://www.defmacro.org/2013/07/23/startup-lessons.html)
-[startup lessons with comments](https://news.ycombinator.com/item?id=6209689l)


#### startup clone
pinterest clone
-[pinterest clone](http://overshard.github.com/pinry/)

I iphone app
-[iphone app](https://parse.com/anywall)

#### startup website design template,
- [startup landing page](https://news.ycombinator.com/item?id=6291123)
- [Free bootstrap template](http://startbootstrap.com/)

#### Adding https ssl to site
- [How to http to https](https://news.ycombinator.com/item?id=6446955)


#### Startup Lessons,

- [startup lessons learned](https://news.ycombinator.com/item?id=6522636)
- [Lessons learned from startup](https://news.ycombinator.com/item?id=6566328)
- [website crawling](https://news.ycombinator.com/item?id=6572677)
- [startup lessons](https://news.ycombinator.com/item?id=6656728)
-  [Startup unicorn, a round about startup](http://techcrunch.com/2013/11/02/welcome-to-the-unicorn-club/)
- [Startup lessons](https://news.ycombinator.com/item?id=6676494)
- [startup lessons](https://news.ycombinator.com/item?id=6989971)

#### Pitching startup,
- [Linkedin pitching in 2004](http://reidhoffman.org/linkedin-pitch-to-greylock/)
- [startup marketing template](http://daniellegeva.com/2014/09/09/startup-marketing-plan-template/)

#### SEO,
 - [what is seo](https://news.ycombinator.com/item?id=6580817)


#### Y Combinator,
- [submit application to Y combinator](https://news.ycombinator.com/item?id=6588233)


#### content marketing engine

- [How I built content marketing engine](http://tomtunguz.com/content-marketing-engine/)


##### Analytics,

- [free analytics product](Built scalable backend systems from scratch at two previous startups - Twurler and Lexity.)

- [twitter analytics](http://topsy.com/)

- #### startup lawyer
- [Startup lawyer](https://lawpal.com/#1)

#### startup company

- [startup company](https://angel.co/)

#### Email introduction,

- [Email introduction](https://news.ycombinator.com/item?id=6901713)

#### Additional income,
-[after quitting job](http://nathanbarry.com/2013-review/)

#### Startup equity options
-[startup equity options explained](https://news.ycombinator.com/item?id=8270023)
