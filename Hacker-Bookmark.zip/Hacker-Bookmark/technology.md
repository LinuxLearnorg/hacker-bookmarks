#### Async io,

- [async io for JVM, websocket, comet](https://github.com/Atmosphere/atmosphere)
- [comparing play framework with node.js](https://news.ycombinator.com/item?id=6848806)
- [reactive manifesto](http://www.reactivemanifesto.org/)


-[About Dockers](https://news.ycombinator.com/item?id=6888623)


#### Issues with technology,

-[why spring framework sucks](https://news.ycombinator.com/item?id=6963041)


#### Unix 
-[Unix monitoring](http://cockpit-project.org/)
