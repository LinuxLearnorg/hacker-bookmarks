

######Bitcoin ############

-[Building for Blockchain](http://blog.ycombinator.com/building-for-the-blockchain/)


-[free ebook bitcoin](http://chimera.labs.oreilly.com/books/1234000001802/index.html)
