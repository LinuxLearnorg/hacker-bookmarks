#### shell scripting,

-[Shell scripting](https://news.ycombinator.com/item?id=6209689l)


-[better bash](http://robertmuth.blogspot.com/2012/08/better-bash-scripting-in-15-minutes.html)

- [follow up to better bash](https://news.ycombinator.com/item?id=7595499)

-[better bash](https://duckduckgo.com/?q=bash+%5B+-z+hello+%5D)


-[ETL workflow](https://github.com/mara/data-integration)
