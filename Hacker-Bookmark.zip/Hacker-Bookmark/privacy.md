
#### Privacy

-[Restore privacy](https://restoreprivacy.com/)

-[Alternative to google](https://restoreprivacy.com/google-alternatives/)

-[Delete personel data from the Internet](http://www.cnet.com/how-to/remove-delete-yourself-from-the-internet/)

-[Facebook privacy](http://paul.henrich.me/posts/2015/02/facing-facebook.html)
