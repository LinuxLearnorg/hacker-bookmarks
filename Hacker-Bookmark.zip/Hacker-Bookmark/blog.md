### hadoop blog
-[spark java ](https://vanwilgenburg.wordpress.com/)

-[Technology evanglist good one](http://www.kai-waehner.de/blog/)

-[Postgres blog](https://brandur.org/articles)


#### Blog

- [Best everyday blog](https://news.ycombinator.com/item?id=13849430)

-[1](https://blog.acolyer.org/)

-[2](https://dev.to/)

-[3](http://highscalability.com/)

-[4](https://www.oreilly.com/ideas)


####summly ##########

http://hackingdistributed.com/2013/03/26/summly/

#### good blogs to read, to write your own blog,
- [Ron blog](http://blog.rongarret.info/)
- [Ron's google ramblings](http://www.flownet.com/ron/xooglers.html)
-

#### Bigdata blog

-[CDH, hbase, morphline blog](http://techkites.blogspot.com/search?updated-min=2015-01-01T00:00:00-08:00&updated-max=2016-01-01T00:00:00-08:00&max-results=3)
