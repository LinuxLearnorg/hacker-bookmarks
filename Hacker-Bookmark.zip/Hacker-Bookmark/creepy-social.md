##### creepy social network

-[creepy linkedin](http://www.interactually.com/linkedin-creepiest-social-network/) 
-[hackernew comments](https://news.ycombinator.com/item?id=5680680)
