
#### Slideshare link, since you can't save 

-[10 Things to get most of hadoop cluster](http://www.slideshare.net/Hadoop_Summit/radia-srinivas-june261120amroom210c)

-[cloudera mapreduce](http://www.slideshare.net/Hadoop_Summit/optimizing-mapreduce-job-performance)
