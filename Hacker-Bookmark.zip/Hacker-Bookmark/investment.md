All about stoc market investment.

#####investment
-[index fund may work too well](http://www.bloombergview.com/articles/2015-07-22/index-funds-may-work-a-little-too-well)
-[follouw up discussion HY](https://news.ycombinator.com/item?id=10009740)

-[Investment for geeks](https://training.kalzumeus.com/newsletters/archive/investing-for-geeks?__s=esaiz3kazigwidftsigk)

-[follow up comments](https://news.ycombinator.com/item?id=12514971)

