
#### Docker #########

-[Serverless docker beta](https://zeit.co/blog/serverless-docker)


#### Emerging Tech Notes only

- Kafka/Spark/Storm/Hbase
- Scala/Python

-[Good tuturial on Kafka](http://sookocheff.com/post/kafka/kafka-in-a-nutshell/)

#### Kubernetes

-[Kubernetes for personal project](http://www.doxsey.net/blog/kubernetes--the-surprisingly-affordable-platform-for-personal-projects)

-[Follow up article on kubernetes](https://news.ycombinator.com/item?id=18111665)

-[Kubernetes by doing](https://www.magicsandbox.com/)

-[Kubernetes by example (Jun 17)](http://kubernetesbyexample.com/)



#### Technology talk

-[Best technology talk](https://news.ycombinator.com/item?id=18217762)
