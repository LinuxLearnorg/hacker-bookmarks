#### Habits,

-[The 7 habits of higly overrated people](https://news.ycombinator.com/item?id=6965295)


#### Freedom,

-[the reall use of money to buy freedom](https://news.ycombinator.com/item?id=6958695)
