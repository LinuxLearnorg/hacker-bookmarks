#### Programmers Productivity

-[Programmers productivity](http://antirez.com/news/112)


#### General productive,

- [Taking Notes](https://news.ycombinator.com/item?id=6406198)
- [How to be Successful](https://news.ycombinator.com/item?id=6547912)

-[Transform anything with one example](http://www.transformy.io/#/)
-[Hacker comment on this](https://news.ycombinator.com/item?id=9432949)



#### Cloning a website

-[Clone a website](http://motherboard.vice.com/read/clone-zone-is-an-easy-tool-for-building-fake-websites)
