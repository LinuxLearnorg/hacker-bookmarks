
-[Swift tutorial](http://samvlu.com/tutorials.html)

-[Mac os x ssl setup](https://gist.github.com/jed/6147872)

-[all spark notebook](https://github.com/jupyter/docker-stacks/tree/master/all-spark-notebook)


-[docker on os X](https://blog.andyet.com/2016/01/25/easy-docker-on-osx/)
-[comments docker on os X](https://news.ycombinator.com/item?id=10969052)
