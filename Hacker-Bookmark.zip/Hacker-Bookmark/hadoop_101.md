#### Hadoop Blog

-[Good one Hadoop scalable blog](http://highlyscalable.wordpress.com/)
-[Hate hadoop](http://www.chrisstucchio.com/blog/2013/hadoop_hatred.html)
-[martin kleppman](http://martin.kleppmann.com/2012/12/05/schema-evolution-in-avro-protocol-buffers-thrift.html)

##### Future of MapReduce,
-[Alternative to mapreduce](https://news.ycombinator.com/item?id=7957345)

#### Big data,

- [hadoop dead](http://www.dataintoresults.com/2013/04/hadoop-landscape-review-2013/)
- [userful unix commands to read CSV](http://www.gregreda.com/2013/07/15/unix-commands-for-data-science/)
- [the above with the comments](https://news.ycombinator.com/item?id=6046682)


#### Hadoop Intro,
- [A good intro to hadoop](http://bradhedlund.com/2011/09/10/understanding-hadoop-clusters-and-the-network/)
- [HBase debate](http://www.informationweek.com/software/enterprise-applications/big-data-debate-will-hbase-dominate-nosq/240159475)

-[Thinking Hadoop with mapreduce](http://blog.xebia.com/2009/07/02/thinking-mapreduce-with-hadoop/)

#### variou hadoop framework comparisons,
- [Amazon Redshift](http://dailytechnology.net/2013/08/03/redshift-what-you-need-to-know/)
- [Big data benchmark, impala,hive](https://amplab.cs.berkeley.edu/benchmark/)

#### Practical intro to data science
-[Intro to data science](http://blog.zipfianacademy.com/post/46864003608/a-practical-intro-to-data-science)
-[Data science competiton](http://www.kaggle.com/)

#### HDFS,

- [Hadoop blog from facebook developer](http://hadoopblog.blogspot.com/)
- [A good intro to HDFS](http://www.aosabook.org/en/hdfs.html)


HBase tutorial:
- http://www.slideshare.net/larsgeorge/realtime-analytics-with-hadoop-and-hbase
- [Hbase basic](http://jimbojw.com/wiki/index.php?title=Understanding_HBase_and_BigTable)
- [Hbase storage Architecture](http://www.larsgeorge.com/2009/10/hbase-architecture-101-storage.html)

-[good hadoop/hbase blog](http://kickstarthadoop.blogspot.com/)

hadoop at twitter:
- http://architects.dzone.com/articles/how-does-twitter-use-scribe

#### Search,

-[Elastic search](http://blog.klout.com/2011/12/find-your-klout/)
WEBSITE for Hadoop:

-[hstack](http://hstack.org/)
-[](http://radar.oreilly.com/2011/06/getting-started-with-hadoop.html)
-[](http://www.hortonworks.com/new-apache-pig-features-part-1-macro/)

Hadoop Software:
- [Hadoop library for compression](http://code.google.com/p/hadoop-snappy/)

- [Hadoop packaging and test](http://wiki.apache.org/incubator/BigtopProposal)

Commerical products around Hadoop:
- http://www.mapr.com/products.html
- http://www.stat.purdue.edu/~sguha/rhipe/
- http://www.karmasphere.com/Products-Information/karmasphere-studio.html
- http://www.informatica.com/products_services/powercenter/Pages/index.aspx
- http://lucene.472066.n3.nabble.com/Is-this-a-fair-summary-of-HDFS-failover-td2493844.html

PIG Tutorial:
- http://www.slideshare.net/hadoop/practical-problem-solving-with-apache-hadoop-pig
- http://parand.com/say/index.php/2008/06/19/pig-hadoop-commands-and-sample-results/

PIG:
- http://www.simon-fortelny.com/?p=118

Programming pig:
- http://ofps.oreilly.com/titles/9781449302641/index.html

Working on PIG:
- http://blog.linkedin.com/2010/07/01/linkedin-apache-pig/

PIG performance:
- http://ofps.oreilly.com/titles/9781449302641/making_pig_fly.html
- http://jonathanhui.com/hadoop-distributed-file-system-hdfs
- http://www.simon-fortelny.com/?p=118


GitHUb
- https://github.com/pranab/estado

