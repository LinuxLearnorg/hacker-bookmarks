

##### Performance

-[spark scale at facebook](https://code.facebook.com/posts/1671373793181703/apache-spark-scale-a-60-tb-production-use-case/)

-[Twitter scale](https://blog.twitter.com/2017/the-infrastructure-behind-twitter-scale)
