
#### Unix top command
- [unix top command realtime](http://scoutapp.github.io/scout_realtime/)

#### Unix,
-[Useful Unix commands](https://news.ycombinator.com/item?id=6360320)

#### Vim tips
-[Vim tips](https://news.ycombinator.com/item?id=7943575)
