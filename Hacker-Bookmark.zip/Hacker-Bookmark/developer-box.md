#### sync

-[Sync to dropbox](http://lpan.io/one-liner-dropbox-client/)

-[Sync anywhere syncthing](https://syncthing.net/)

#### development setup #####

-[How to set up world-class continuous deployment using free hosted tools](https://simonwillison.net/2017/Oct/17/free-continuous-deployment/)


#### config developer box.

- [config Mac development tools](http://www.josebrowne.com/from-windows-to-mac-dev.html)
- [setup sublime text2](http://drewbarontini.com/setup/sublime-text/)


####dev ops
-[bad devops](http://jeffknupp.com/blog/2014/04/15/how-devops-is-killing-the-developer/)

-[Monitor Errors/Exceptions] (https://airbrake.io/)
-[roll](https://rollbar.com/)
-[errbit](https://github.com/errbit/errbit (can be hosted on Heroku for free)

#### best practices

-[best practices in modern web projects](https://news.ycombinator.com/item?id=7953616)


#### Mac
-[Hackers guide to setup mac](http://lapwinglabs.com/blog/hacker-guide-to-setting-up-your-mac)
-[follow up comments](https://news.ycombinator.com/item?id=8402079)
