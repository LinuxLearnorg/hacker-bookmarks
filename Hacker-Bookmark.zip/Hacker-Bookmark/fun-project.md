#### Solar

-[Solar buy vs lease](https://www.bloomberg.com/graphics/2019-sunrun-solar-panels/)

-[follow up comment](https://news.ycombinator.com/item?id=19162382)

### 

-[Build a purifier](https://www.uofmhealth.org/news/sinus-hepa-0630)
-[comments](https://news.ycombinator.com/item?id=18445652)

#### Good read

-[find good recomendation from good people](http://abyjames.com/projects/recommendations/)

#### portfolio

-[building killer portfolio](https://zen-of-programming.com/kickass-portfolio)

-[follo-up hacker comments](https://news.ycombinator.com/item?id=17671490)


##### food 
-[local harvest](https://harvestsignal.com/)
-[what grows in your area](https://news.ycombinator.com/item?id=15739744)

#### Bitcoin

-[Analyzing crypto currency](https://blog.patricktriest.com/analyzing-cryptocurrencies-python/?utm_source=hackernews)

#### love

-[150 dates in 4 months](https://themission.co/looking-for-the-one-how-i-went-on-150-dates-in-4-months-bf43a095516c)

#### wifi
-[how wifi works](http://www.verizoninternet.com/bookmark/how-wifi-works/)


#### VPN

-[setup VPN server](https://pimylifeup.com/raspberry-pi-vpn-server/)

-[vpn setup](https://vpnreport.org/)


#### TV

-[Introduction to video Technology](https://github.com/leandromoreira/digital_video_introduction)

-[Selecting TV ](http://www.snarky.ca/what-to-look-for-in-a-new-tv)
- [TV reviews](http://ca.rtings.com/tv)
- [TV wire cutter](http://thewirecutter.com/leaderboard/tvs/)

######Health

-[body building](https://www.julian.com/learn/muscle/intro)
-[follow up ](https://news.ycombinator.com/item?id=12618223)

-[Reditt-body building](https://www.reddit.com/r/Fitness/wiki/index)


### This is fun project page,

- [fake online locksmith](http://www.nytimes.com/2016/01/31/business/fake-online-locksmiths-may-be-out-to-pick-your-pocket-too.html)

-[2016 best skills](http://blog.linkedin.com/2016/01/12/the-25-skills-that-can-get-you-hired-in-2016/)

#### Airline booking,

- [itasoftware](https://www.itasoftware.com/)


#### Forest

-[Create forest in 2 yeara](http://www.afforestt.com/index.html)


#### camera

-[How camera works basics](http://www.objc.io/issue-21/how-your-camera-works.html)

#### DIY Drone
- [DiyDrones](http://diydrones.com/)


#### Newibe guide to bayarea,
- [Bay area guide](https://news.ycombinator.com/item?id=6502430)


#### Chess game,

- [How to improve chess fast](https://news.ycombinator.com/item?id=6791742)


#### DIY

-[Best online course](http://www.diygenius.com/mind-expanding-documentaries/)


#### Fun with facebook
-[Facebook messenger](https://medium.com/@arankhanna/stalking-your-friends-with-facebook-messenger-9da8820bd27d)
-[follow up comments](https://news.ycombinator.com/item?id=9609286)


#### Weight Gain

-[weight gain](http://matt.might.net/articles/hacking-strength/)
