#### Remote Jobs

-[List of Remote jobs sites](https://docs.google.com/spreadsheets/d/1JfNAbUX_lN9K3MCNHO15GJtJ5qpk7H9Cl3xTBwv2FR8/htmlview?usp=drive_web&sle=true)


#### Salary

-[google, microsoft, amazon salary](https://blog.step.com/2016/04/08/an-open-source-project-for-tech-salaries/)


#### Startup companies
- [infer](https://www.infer.com/)
- [throwout your resume](http://throw-out-your-resume.com/)
- [e-commerce digital-Boomerang](http://www.boomerangcommerce.com/)
-  [Technology in 2015 ](http://a16z.com/2015/01/22/16-things/)
 
#### Good resume 
- [Ron resume ](http://www.flownet.com/ron/resume.html)


#### Stock options

-[Negotating stock options](http://jvns.ca/blog/2015/12/30/do-the-math-on-your-stock-options/)
-[follow-up comments](https://news.ycombinator.com/item?id=10811570)
- [stock options in startup](http://www.scribd.com/doc/55945011/An-Introduction-to-Stock-Options-for-the-Tech-Entrepreneur-or-Startup-Employee)
- [understanding the stock options](https://news.ycombinator.com/item?id=6205542)
- [data based company palantir](http://www.palantir.com/)

- [An engineer guide to Stock options](http://blog.alexmaccaw.com/an-engineers-guide-to-stock-options) 
##### companies in sunnyvale in media
-[statup company in sunnyvale](http://sysomos.com/contact)

#### hacker new job posting
-[septemeber job ](https://news.ycombinator.com/item?id=10152809)
