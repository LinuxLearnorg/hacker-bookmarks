
#### Problem and solution doc,

-[Simple yarn issues](https://issues.apache.org/jira/secure/attachment/12693526/SparkYARN.pdf)

