#### Algorithms
- [big o notation](http://bigocheatsheet.com/)
- [json api](http://jsonapi.org/)
