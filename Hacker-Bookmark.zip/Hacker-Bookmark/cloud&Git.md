#### AWS,

-[AWS and GCP comparison](https://metamarkets.com/2017/big-cloud-data-aws-and-gcp/)

-[Cloud comparison AWS google microsoft](https://www.arador.com/ridiculous-bandwidth-costs-amazon-google-microsoft/)


 -[AWS sail ](https://news.ycombinator.com/item?id=13072155)

 -[Guide to amazon web services](https://github.com/open-guides/og-aws)

-[bit coin on AWS](https://news.ycombinator.com/item?id=6911908)

-[Things I had knew about AWS](https://news.ycombinator.com/item?id=7172060)

-[Save on AWS](https://news.ycombinator.com/item?id=7184179)

-[Amazon s3 mistake](https://news.ycombinator.com/item?id=8817299)

- [A Comprehensive Guide to Building a Scalable Web App on Amazon Web Services](https://www.airpair.com/aws/posts/building-a-scalable-web-app-on-amazon-web-services-p1?wed)


-[cloud comparision GCE vs AWS](https://thehftguy.wordpress.com/2016/11/18/google-cloud-is-50-cheaper-than-aws/)


##### cheap cloud

Amazon Lightsail 1GB is no match for $10 VPS from Linode, DO, Vultr...
Dec 06 2016
TLDR: Amazon Lightsail 1GB will melt down with less than 15% sustained cpu usage

Amazon Lightsail launched to much fanfare last week, threatening the business of competitors like DigitalOcean, Linode, OVH, Atlantic.net and many others who have long offered simple, cheap, all-included price VPS servers.

At VpsBenchmarks, we specialize in testing this type of VPS so we wasted no time firing up an instance of the 1GB 1 core $10 flavor of Lightsail. I setup our web app on this VPS, pointed traffic at it and also ran Sysbench tests.

##### Docker

-[cloud docker](https://hyper.sh/)

#### Git,

-[Git documentation](http://www-cs-students.stanford.edu/~blynn/gitmagic/index.html)

-[Use Git effectively](http://devcharm.com/pages/46-improve-your-git-workflow)

-[simple Git use](http://blogs.atlassian.com/2014/01/simple-git-workflow-simple/)

#### Big Data Cloud
-[qubole - Big data on cloud](http://www.qubole.com/)

#### Amazon Web service

-[Amazon web service](https://www.expeditedssl.com/aws-in-plain-english)
