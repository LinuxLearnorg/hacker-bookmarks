Modern web framework
 - [the new React js framework better than Anjurlarjs](https://news.ycombinator.com/item?id=7738194)
 - [Good Meter.js tutorial](http://joshowens.me/getting-started-with-meteor-js/)
 - [Perfect javascript framework](https://dev.opera.com/articles/perfect-javascript-framework/)


h2 helpful Angular tips
- [startig Angular](http://blog.whydoifollow.com/post/angularjs-where-to-start)
- [Tips and tricks](http://deansofer.com/posts/view/14/AngularJs-Tips-and-Tricks-UPDATED)
- [startAngularjs](http://stephanebegaudeau.tumblr.com/post/48776908163/everything-you-need-to-understand-to-start-with)
- [60 minute video tutorila](http://weblogs.asp.net/dwahlin/archive/2013/04/12/video-tutorial-angularjs-fundamentals-in-60-ish-minutes.aspx)
- [Angular cheatsheet](http://www.cheatography.com/proloser/cheat-sheets/angularjs/)
- [Angularjs overview](http://glennstovall.com/blog/2013/06/27/angularjs-an-overview/)

- [Youtube intergration with angularjs good one](https://github.com/mikecrittenden/toogles)
- [Angularjs in 7 steps](http://www.ng-newsletter.com/posts/beginner2expert-how_to_start.html)
- [Angularjs with backend](https://blog.backlift.com/entry/angular-tut2)
- [Angularjs rocks](http://angular-tips.com/blog/2013/08/why-does-angular-dot-js-rock/)
- [Angularjs tutorial](http://www.thinkster.io/pick/GUIDJbpIie/angularjs-tutorial-learn-to-build-modern-web-apps)
- [Angular js basics](https://coderwall.com/p/3qclqg)
- [AngularJs directive](http://seanhess.github.io/2013/10/14/angularjs-directive-design.html)

#### javascript
 CommonJS is a common moudule required for the javascript. RequireJS is a implemention of 
 commonjs.
 
 I researched following Javascript framework before landing on Anjularjs,
 - backoneJS, it is a very basic framework
 - The other 3 mvc framework are
   -KnockoutJs 
   -EmberJS
   -Angulrjs

#### D3,
- [startup tutorial D3](http://bost.ocks.org/mike/selection/)


#### Meteor,
- [discover meteor](http://www.discovermeteor.com/)  

#### AngularJs demo project,
-[Using angular with firebase](http://firereader.io/app/#/demo)


#### NodeJs
- [good tutorial on nodejs](http://blog.modulus.io/absolute-beginners-guide-to-nodejs)


#### New technology,
- [docker a packaging system](https://news.ycombinator.com/item?id=6291123)
- 

##### Go lang web framework
- [go lan web framework](https://news.ycombinator.com/item?id=6801024)

### side effect of angularjs
- [side effect of Javascript framework](https://news.ycombinator.com/item?id=7255227)

