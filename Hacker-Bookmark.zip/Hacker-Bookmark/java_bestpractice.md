
#### Best Practice on java 8

 -[java best practice ](https://news.ycombinator.com/item?id=7680338)
