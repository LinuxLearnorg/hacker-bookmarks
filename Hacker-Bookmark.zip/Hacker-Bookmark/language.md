


#########New language ###########

-[comparison b'n Swift vs Kotlin](http://nilhcem.com/swift-is-like-kotlin/)

-[Follow up comments ](https://news.ycombinator.com/item?id=14364612)

-[Kotlin in y minutes](https://learnxinyminutes.com/docs/kotlin/)

-[kotlin 101](http://www.slatekit.com/kotlin101.html)
