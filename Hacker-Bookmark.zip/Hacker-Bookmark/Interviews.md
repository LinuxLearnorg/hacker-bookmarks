
#### Job site

-[best job site for software engineers in startup](https://triplebyte.com/)

#### general

-[Crackiing the coding interview](https://blog.usejournal.com/i-interviewed-at-six-top-companies-in-silicon-valley-in-six-days-and-stumbled-into-six-job-offers-fe9cc7bbc996)

-[follow up comments](https://news.ycombinator.com/item?id=18942572)

-[75 programming interview questions](http://www.java67.com/2018/05/top-75-programming-interview-questions-answers.html)

-[Core concepts of Spark](https://blog.usejournal.com/spark-study-notes-core-concepts-visualized-5256c44e4090)

-[Cassandra permonace improvement](https://news.ycombinator.com/item?id=16523064)

-[In memory apache Arrow](https://www.dremio.com/origin-history-of-apache-arrow/)

-[MongoDB performance](https://severalnines.com/blog/performance-cheat-sheet-mongodb)

-[Comparing various database type](https://www.allthingsdistributed.com/2018/06/purpose-built-databases-in-aws.html)

-[Learn how to design large-scale systems. Prep for the system design interview. Includes Anki flashcards.](https://github.com/donnemartin/system-design-primer)

-[Uber engineering blog](https://eng.uber.com/uber-big-data-platform/)

#### coding interviews

-[Dynamic programming Interview problems](http://blog.refdash.com/dynamic-programming-tutorial-example/)

-[Coding interviews experience](http://fuzzyblog.io/blog/jobhound/2018/04/24/ten-things-i-learned-from-a-job-hunt-for-a-senior-engineering-role.html)

-[followup comments](https://news.ycombinator.com/item?id=16912546)


-[500 interview quetions](https://techiedelight.quora.com/500-Data-Structures-and-Algorithms-practice-problems-and-their-solutions?__filter__&__nsrc__=2&__snid3__=1594232728&amp;share=1)

-[Techie delight](http://www.techiedelight.com/list-of-problems/)

-[coding interview books](https://github.com/yangshun/tech-interview-handbook)

-[coding web site](https://medium.freecodecamp.org/the-10-most-popular-coding-challenge-websites-of-2016-fb8a5672d22f)

-[Algorithm and data structures](https://medium.com/coderbyte/how-to-get-good-at-algorithms-data-structures-d33d5163353f)

#### Garbage collector

-[Java 11 Z garbage collector](https://www.opsian.com/blog/javas-new-zgc-is-very-exciting/)

#### SQL
-[why SQL beating NoSql](https://blog.timescale.com/why-sql-beating-nosql-what-this-means-for-future-of-data-time-series-database-348b777b847a)

-[RDBMS columar vs row ](http://dbmsmusings.blogspot.com/2017/10/apache-arrow-vs-parquet-and-orc-do-we.html)

Database-performance-tricks
These three data warehouses undoubtedly use the standard performance tricks: columnar storage, cost-based query planning, pipelined execution, and just-in-time compilation

-[Good comparison between Mysql and prostgres](https://blog.dumper.io/showdown-mysql-8-vs-postgresql-10/)

-[Follow-up comments](https://news.ycombinator.com/item?id=17133470)

-[postgresql extension db comparisons](https://news.ycombinator.com/item?id=18295041)

-[SQL joins venn diagram](https://blog.jooq.org/2016/07/05/say-no-to-venn-diagrams-when-explaining-joins/)

The first section is about how Venn works fine for AND and OR because it’s set theory and Venn works just fine for examples (maybe not every problem though). Joins are not sets. They are Cartesian products.

#### Kafka 

-[cassandra 101](https://blog.insightdatascience.com/the-total-newbies-guide-to-cassandra-e63bce0316a4)

-[NY article why they used Kafka](https://www.confluent.io/blog/publishing-apache-kafka-new-york-times/)

-[follow-up comment on Y on kafka inersting](https://news.ycombinator.com/item?id=15184640)


#### regex
-[regex tutorial](http://www.rexegg.com/)


-[learn regex](https://github.com/zeeshanu/learn-regex)
-[regex testing](http://www.regexplanet.com/)
-[regex testing](http://regexr.com/)
-[regex 101](https://regex101.com/)


#### Algorithms
-[Trees algorithm](https://sadanand-singh.github.io/posts/treebasedmodels/#.WXT8Kli2pUw.hackernews)


#### Interview

-[How to interview Engineers](http://blog.triplebyte.com/how-to-interview-engineers)

#### Interview

-[Common data structures](https://medium.freecodecamp.org/10-common-data-structures-explained-with-videos-exercises-aaff6c06fb2b)

-[programming quiz](https://quiz.triplebyte.com/)

-[lessons from 3000 technical interview](http://blog.interviewing.io/lessons-from-3000-technical-interviews/)

-[Lessons from 3000 technical interivew followup](https://news.ycombinator.com/item?id=13272840)


-[NoSQL database comparison](https://medium.com/baqend-blog/nosql-databases-a-survey-and-decision-guidance-ea7823a822d#.14guit9rr)

-[Streaming process comparison](https://www.alooma.com/blog/stream-processing-101)

-[pipeline map data engineering](https://blog.insightdatascience.com/the-new-data-engineering-ecosystem-trends-and-rising-stars-414a1609d4a0#.thphny7xx)


#### Tech interviews at various company.

-[Prepartion for google interview](https://medium.freecodecamp.com/why-i-studied-full-time-for-8-months-for-a-google-interview-cc662ce9bb13#.7zc4h6vtr)

-[Interview process](https://blog.readme.io/how-we-designed-our-interview-process/)

-[Tech interview at Amazon](http://sobit.me/2016/07/08/amazon-software-engineer-interview/)

#### coarse era material 

-[Coursea archive](https://archive.org/details/archiveteam_coursera)

- [Recent google tech interview](http://www.gwan.com/blog/20160405.html)


#### Techinical interview sucks.

-[You suck at technical interview](http://seldo.com/weblog/2014/08/26/you_suck_at_technical_interviews)
-[Follow up](https://news.ycombinator.com/item?id=11874584)


#### Interview website

-[top 10 programming questions](http://www.programcreek.com/2012/11/top-10-algorithms-for-coding-interview/)

-[CareerCup Trees Graphs](https://www.careercup.com/page?pid=trees-and-graphs-interview-questions)

-[Geeksforgeeks top 10 intervew q](http://www.geeksforgeeks.org/top-25-interview-questions/)

-[HackerRank](https://www.hackerrank.com/feed)

-[interviewcake](https://www.interviewcake.com/article/java/coding-interview-tips)

-[Interview.io](http://blog.interviewing.io/technical-interview-performance-is-kind-of-arbitrary-heres-the-data/)

-[Good on threads](http://tutorials.jenkov.com/)

#### Interview Questions
-[Data Structures and Algorith with answers](http://www.ideserve.co.in/)

-[Epic list of interview questions](http://katemats.com/interview-questions/)

-[How to pass programming interviews](http://blog.triplebyte.com/how-to-pass-a-programming-interview)

-[Tech salary](https://docs.google.com/spreadsheets/d/1a1Df6dg2Pby1UoNlZU2l0FEykKsQKttu7O6q7iQd2bU/htmlview?usp=sharing&sle=true)

#### Interview books

-[Do the programming interviews](http://blog.triplebyte.com/how-to-pass-a-programming-interview)

-[Follow up to the above post](https://news.ycombinator.com/item?id=11246917)

### Java 8

-[Guide to Java 8](https://github.com/winterbe/java8-tutorial)

-[Java 8 tutorial follow up ](https://news.ycombinator.com/item?id=10573399)

### java performance blog

-[why i hate java](http://warp.povusers.org/grrr/java.html)

-[java performance blog takipi](http://blog.takipi.com/)

-[Java memory guide, best for interview](https://www.ravenbrook.com/project/mps/master/manual/html/mmref/lang.html)

-[Java memory garbage collector ](http://eivindw.github.io/2016/01/08/comparing-gc-collectors.html)

-[Modern garbage collector](https://medium.com/@octskyward/modern-garbage-collection-911ef4f8bd8e#.uf2s5b475)



#### Helpful desing doc
-[Helpful design doc template](https://issues.apache.org/jira/secure/attachment/12693526/SparkYARN.pdf)


#### Hadoop and hive programming example
- [hadoop and hive examples](https://sites.google.com/site/hadoopandhive/)


#### Programming challenges
- [Hacker challenge](https://www.hackerrank.com/)

- [30 interviews](http://blog.triplebyte.com/three-hundred-programming-interviews-in-thirty-days)
-[Follow up comment](https://news.ycombinator.com/item?id=9766816) 

#### Interview

- [Kotlin](https://realm.io/news/droidcon-michael-pardo-kotlin/)

- [Hiring top performer](http://firstround.com/review/hire-a-top-performer-every-time-with-these-interview-questions/)
- [follow up on hacker news](https://news.ycombinator.com/item?id=10290882)
- [Interview candidates](http://ericlippert.com/2015/06/08/interviewing-candidates/)
- [Interview experience at apple](https://lmjabreu.com/post/700-billion/)
- [follow up comments ](https://news.ycombinator.com/item?id=9104818)
- [screwed up the interview](http://blog.ellenchisa.com/2014/04/13/stuff-ive-screwed-up-while-interviewing/)
- [Follow up comments](https://news.ycombinator.com/item?id=9142871)
- [career guide](http://www.breakoutcareers.com/)

####  Math
- [Translating Math into Java code, set, unions,maps](http://matt.might.net/articles/discrete-math-and-code/)

#### Performance
- [Javascript performance measure](http://www.html5rocks.com/en/tutorials/memory/effectivemanagement/)
- [Java performance tuning](http://shipilev.net/blog/2015/black-magic-method-dispatch/)
- [Cassandra issues](http://blog.parsely.com/post/1928/cass/)
- [Google performance tools](https://developers.google.com/optimization/)


#### interview experience
- [Interview expeience](http://robertheaton.com/2014/03/07/lessons-from-a-silicon-valley-job-search/)
- [Follow-up hacknews](https://news.ycombinator.com/item?id=7428469)


#### Interview,
- [brain test](http://www.brainmetrix.com/)
- [coding for interviews](http://codingforinterviews.com/)
- [Tech interview process](https://news.ycombinator.com/item?id=7259845)
- [Stupid interview question](https://news.ycombinator.com/item?id=7953725)
- [Interview  questions](http://weblog.raganwald.com/2006/06/my-favourite-interview-question.html)
- [Tought interview questions](https://oj.leetcode.com/problems/)
##### Interviews website

- [leet code](https://leetcode.com/)

- [follow up hacker news](https://news.ycombinator.com/item?id=17101046)

- [free programming books](https://github.com/vhf/free-programming-books/blob/master/free-programming-books.md)
- [Interview website](http://www.geeksforgeeks.org/)
- [deligtful puzzles](http://gurmeet.net/puzzles/)
- [first time Interview ](http://firstround.com/article/The-anatomy-of-the-perfect-technical-interview-from-a-former-Amazon-VP)

- [fucked up google interview](https://news.ycombinator.com/item?id=6243627)

- [why secure email is difficult](https://news.ycombinator.com/item?id=6243936)

- [I will not do another tech interview](https://news.ycombinator.com/item?id=6251087)

- [Algorithms](https://news.ycombinator.com/item?id=6283663)

- [Hire right](https://news.ycombinator.com/item?id=6432781)

- [startup interview process](https://news.ycombinator.com/item?id=6454140)

- [Hadoop interview questions](http://www.fromdev.com/2010/12/interview-questions-hadoop-mapreduce.html)

- [Core java blog, good for interview](http://vanillajava.blogspot.com/)

#### Interview questions,

- [coding interview](https://news.ycombinator.com/item?id=6559404)

- [40 collections questions](http://www.javacodegeeks.com/2013/02/40-java-collections-interview-questions-and-answers.html)
- [Java interview questions](http://javaadmin.com/category/interview-questions/)

- [Java interview questions](http://javarevisited.blogspot.com/2013/03/top-15-data-structures-algorithm-interview-questions-answers-java-programming.html)

- [online resouces](https://www.quora.com/Job-Interview-Questions/What-are-good-free-online-resources-to-prep-for-code-interviews)

- [interview questions](https://news.ycombinator.com/item?id=6949474)
-  [Steve yegge google interview quesiton](http://steve-yegge.blogspot.ca/2008/03/get-that-job-at-google.html)

Threads,

- [concurency](https://news.ycombinator.com/item?id=6560214)

#### startup interviews,
- [why startup ask math puzzle to code](https://news.ycombinator.com/item?id=6583580)

- [question to ask your poetential employer](https://news.ycombinator.com/item?id=6701707)
 

#### Hiring software developers,

- [Hiring software developers](http://hesh.am/2013/11/hiring-software-developers/)


#### Algorithms,
-[Algorithms](http://interactivepython.org/courselib/static/pythonds/index.html)
- [DataStructures and algorithms](http://www.cs.usfca.edu/~galles/visualization/Algorithms.html)
- [Problem solving with Algorithms and data structure](http://interactivepython.org/runestone/static/pythonds/index.html)
- [HashMap explained](http://elbenshira.com/blog/the-universal-data-structure/)
- [followup comments](https://news.ycombinator.com/item?id=9804777)


#### Java best practices,

-[Java best practices](http://www.javapractices.com/home/HomeAction.do)


#### Interview prep,

- [Interview prep for google](http://steve-yegge.blogspot.ca/2008/03/get-that-job-at-google.html)
- [hadoop prep for big data](http://horicky.blogspot.com/2010/10/bigtable-model-with-cassandra-and-hbase.html) 

-[code rest prep for interview](http://www.coderust.com/)

#### Garbage collection,

- [Java garbage collection distilled, good one on GC](http://www.infoq.com/articles/Java_Garbage_Collection_Distilled)

- [Inside the java virtuall machine, Garbage collector](http://www.artima.com/insidejvm/ed2/gcP.html)

-[Jvm garbage collection oracle doc](http://www.oracle.com/technetwork/java/javase/gc-tuning-6-140523.html)

- [ruby garbage collection](http://tmm1.net/ruby21-rgengc/)


### algorithms
-[visualize algorithms](http://spin.atomicobject.com/2014/09/03/visualizing-garbage-collection-algorithms/)


The One Commandment of multithreaded programming,
1. Thou Shalt Not touch shared data without synchronization.
  You must know what data is shared, and you must synchronize all access to shared data
(with one exception, when all access is read-only).

2. Thou Shalt minimize and reduce shared mutable data as much as possible, in the 
design stage.Sometimes just making new copy and passing that around might not cause that much of 
a performance penalty vs the time spent debugging synchronization problems.
